---
title: Enhancing Your Applications For Windows 7
categories:
  - Development
permalink: enhancing-your-applications-for-windows-7
date: 2009-11-17 09:36:34
---

<p>I invite you to head over to Developer Fusion, and read my article on &quot;Enhancing Your Applications For Windows 7”.&#160; If you haven’t played with the Windows 7 API Code Pack yet, I definitely recommend it.</p>  <p><a title="http://www.developerfusion.com/article/70531/enhancing-your-applications-for-windows-7/" href="http://www.developerfusion.com/article/70531/enhancing-your-applications-for-windows-7/">http://www.developerfusion.com/article/70531/enhancing-your-applications-for-windows-7/</a></p>