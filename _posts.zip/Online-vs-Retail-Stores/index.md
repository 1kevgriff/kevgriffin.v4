---
title: Online vs. Retail Stores
categories:
  - Deep Thoughts
permalink: online-vs-retail-stores
date: 2010-04-19 06:00:00
---

Something amazing happened the other day.

I wanted to purchase a copy of Splinter Cell: Convinction.  After a little bit of surfing online, I discovered that Walmart had it on sale for $50 (compared to the regular $59.99).  So I drove up to the local Walmart, and walked over to the Video Games section.  Come to discover that the game was $59.99, instead of the $50 I saw online.  Come to discover, the $50 was an “online only price”.

As any good consumer would do, I pulled out my Android phone and started the Amazon app.  Splinter Cell: Conviction was available for $50, and also eligible for free shipping.  Click… click… and I was finished ordering the game… on my phone… while staring at the game in the cabinet.  So instead of giving Walmart my money, I gave it to Amazon.  I was even willing to pay tax to walk out of the store with it right then and there.

There are drawbacks to online stores.  I do have to wait several days for my order, and sometimes that’s not acceptable.  However, when you run an online store along side a brick and mortar, you should be trying to compete more with other online retailers.  “Online only” prices are idiotic, and will only convince me to go to another retailer.  If you advertise a price online, I should be able to go to store and pick up the same item for the same price.

Good job Walmart.  Ask Amazon how they enjoy my money.