---
title: '50 Ways to Avoid, Find and Fix ASP.NET Performance Issues'
permalink: 50-ways-to-avoid-find-and-fix-asp-net-performance-issues
categories: 
  - Self Promotion
id: 728
updated: '2013-01-24 04:34:48'
date: 2013-01-25 05:00:46
---

A couple weeks ago there was a public request on Twitter from the great folks at RedGate to provide tips and tricks for performance in ASP.NET applications.  Come to find out, they selected one of my tips and published it in their ebook "50 Ways to Avoid, Find and Fix ASP.NET Performance Issues".

It's a free download: <a href="http://www.red-gate.com/products/dotnet-development/ants-performance-profiler/entrypage/avoid-find-fix-asp-problems">http://www.red-gate.com/products/dotnet-development/ants-performance-profiler/entrypage/avoid-find-fix-asp-problems</a>

Go grab it today!