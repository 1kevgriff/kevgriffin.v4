---
title: Fix My Computer
permalink: fix-my-computer
date: 2017-05-02 23:30:55
---

I get a lot of requests for companies in the Norfolk and Virginia Beach area that fix personal computers.  Here are a couple references that I think are looking at.

> These references come from friends of mine in the industry.  I have not vetted any of these companies.  Your milage might vary.

*P&P PC*
2468 East Little Creek Road, Norfolk VA 23518
(757)-531-3196
[http://www.pandppc.com](http://www.pandppc.com)
