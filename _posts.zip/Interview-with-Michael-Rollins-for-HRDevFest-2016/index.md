---
title: Interview with Michael Rollins for HRDevFest 2016
categories:
  - Community, User Groups, and Conferences
permalink: interview-with-michael-rollins-for-hrdevfest-2016
date: 2016-09-01 10:56:33
---

Recently, I had the opportunity to sit down with my friend [Michael Rollins](http://www.rollins.io) to talk about life as a mobile SDK developer, drones, and his upcoming HRDevFest keynote on growth through suffering.

Watch the interview for yourself!  Get your tickets for HRDevfest at [http://hrdevfest.org!](http://hrdevfest.org)

<iframe width="854" height="480" src="https://www.youtube.com/embed/J5vov9TuNOU" frameborder="0" allowfullscreen></iframe>

