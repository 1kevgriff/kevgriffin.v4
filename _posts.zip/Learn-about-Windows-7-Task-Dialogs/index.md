---
title: Learn about Windows 7 Task Dialogs
categories:
  - Development
permalink: learn-about-windows-7-task-dialogs
id: 635
updated: '2009-12-01 07:00:00'
date: 2009-12-01 07:00:00
---

<p>Please take a few minutes and travel over to DeveloperFusion where my latest article on Windows 7 Task Dialogs has been published.&#160; If you’ve never used a task dialog before, I would definitely recommend them.&#160; I consider them “Message Box 2.0”.</p>  <p><a title="http://www.developerfusion.com/article/71793/smarten-up-your-ui-with-task-dialogs-the-message-box-20/" href="http://www.developerfusion.com/article/71793/smarten-up-your-ui-with-task-dialogs-the-message-box-20/">http://www.developerfusion.com/article/71793/smarten-up-your-ui-with-task-dialogs-the-message-box-20/</a></p>  <p>Let me know what you think!</p>