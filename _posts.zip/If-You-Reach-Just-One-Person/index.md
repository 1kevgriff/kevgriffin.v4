---
title: If You Reach Just One Person
categories:
  - Deep Thoughts
permalink: if-you-reach-just-one-person
id: 660
updated: '2010-03-29 06:00:00'
date: 2010-03-29 06:00:00
---

<p>After giving a talk, it’s really difficult to judge if you reached any of the attendee’s.&#160; Normally, you get the occasional “good job” or “thanks, that was a big help.”&#160; Today I got a small mention by <a href="http://blog.barkalot.com/">Johnathan Bracken</a>, who was sitting in my <strong>jQuery From The Ground Up</strong> talk at Roanoke Code Camp.&#160; This means a lot, because it shows that my talk stayed in Johnathan’s head past the end of the talk.&#160; </p>  <p>He just started blogging, and mentioned me in his entry <a href="http://blog.barkalot.com/post/I-will-not-run-from-JavaScript-No-More.aspx"><em>I Will Not Run from JavaScript No More</em></a><em>. </em>This is very cool to see.&#160; I wish Johnathan the best of luck in his jQuery adventures!&#160; And I expect him to give a jQuery talk at next year’s code camp.</p>